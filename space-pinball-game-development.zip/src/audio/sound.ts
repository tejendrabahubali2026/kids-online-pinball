/**
 * SoundManager — Web Audio API driven.
 *
 * Placeholder file paths live in /public/sounds/ (see /public/sounds/README.txt).
 * If a file can't be loaded (e.g. it hasn't been added yet), a fully functional
 * synthesized fallback sound is used instead, so the game always has audio.
 */

export type SfxName =
  | 'flipper'
  | 'bumper'
  | 'star'
  | 'sling'
  | 'launch'
  | 'drain'
  | 'gameover'
  | 'orbit'
  | 'ramp'
  | 'bonus'
  | 'save'
  | 'click';

const SFX_PATHS: Record<SfxName, string> = {
  flipper: '/sounds/flipper.wav',
  bumper: '/sounds/bumper.wav',
  star: '/sounds/star.wav',
  sling: '/sounds/sling.wav',
  launch: '/sounds/launch.wav',
  drain: '/sounds/drain.wav',
  gameover: '/sounds/gameover.wav',
  orbit: '/sounds/orbit.wav',
  ramp: '/sounds/ramp.wav',
  bonus: '/sounds/bonus.wav',
  save: '/sounds/save.wav',
  click: '/sounds/click.wav',
};

const MUSIC_PATH = '/sounds/music.mp3';

const midi = (m: number): number => 440 * Math.pow(2, (m - 69) / 12);

export class SoundManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private buffers = new Map<string, AudioBuffer>();

  private musicSource: AudioBufferSourceNode | null = null;
  private musicFileFailed = false;
  private wantMusic = false;

  // Procedural music sequencer state
  private seqTimer: number | null = null;
  private seqStep = 0;
  private seqNextTime = 0;

  muted = false;

  /** Must be called from a user gesture (click / touch). Safe to call repeatedly. */
  init(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();

    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 1;
    this.master.connect(this.ctx.destination);

    this.sfxBus = this.ctx.createGain();
    this.sfxBus.gain.value = 0.55;
    this.sfxBus.connect(this.master);

    this.musicBus = this.ctx.createGain();
    this.musicBus.gain.value = 0.34;
    this.musicBus.connect(this.master);

    // shared white-noise buffer
    const len = Math.floor(this.ctx.sampleRate * 0.6);
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;

    void this.loadAll();
  }

  private async loadAll(): Promise<void> {
    if (!this.ctx) return;
    // music
    try {
      const res = await fetch(MUSIC_PATH);
      if (!res.ok) throw new Error('missing');
      const buf = await this.ctx.decodeAudioData(await res.arrayBuffer());
      this.buffers.set('music', buf);
      if (this.wantMusic && !this.musicSource && this.seqTimer === null) this.startMusic();
    } catch {
      this.musicFileFailed = true;
      if (this.wantMusic) this.startSequencer();
    }
    // sfx files (each individually optional)
    (Object.keys(SFX_PATHS) as SfxName[]).forEach(async (name) => {
      try {
        const res = await fetch(SFX_PATHS[name]);
        if (!res.ok) throw new Error('missing');
        const buf = await this.ctx!.decodeAudioData(await res.arrayBuffer());
        this.buffers.set(name, buf);
      } catch {
        /* synth fallback stays active */
      }
    });
  }

  toggleMute(): boolean {
    this.muted = !this.muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(this.muted ? 0 : 1, this.ctx.currentTime, 0.02);
    }
    return this.muted;
  }

  /** Duck the music while paused. */
  duckMusic(ducked: boolean): void {
    if (this.musicBus && this.ctx) {
      this.musicBus.gain.setTargetAtTime(ducked ? 0.1 : 0.34, this.ctx.currentTime, 0.15);
    }
  }

  /** Suspend/resume the whole context (tab hidden/shown). */
  suspend(): void {
    if (this.ctx && this.ctx.state === 'running') void this.ctx.suspend();
  }

  resume(): void {
    if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume();
  }

  // ---------------------------------------------------------------- music ----

  startMusic(): void {
    this.wantMusic = true;
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    const buf = this.buffers.get('music');
    if (buf) {
      if (this.musicSource) return;
      this.stopSequencer();
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      src.connect(this.musicBus!);
      src.start();
      this.musicSource = src;
    } else if (this.musicFileFailed || !this.buffers.has('music')) {
      // file not present (or still loading) → procedural chiptune loop
      this.startSequencer();
    }
  }

  stopMusic(): void {
    this.wantMusic = false;
    if (this.musicSource) {
      try { this.musicSource.stop(); } catch { /* noop */ }
      this.musicSource = null;
    }
    this.stopSequencer();
  }

  private stopSequencer(): void {
    if (this.seqTimer !== null) {
      window.clearInterval(this.seqTimer);
      this.seqTimer = null;
    }
  }

  /** Cheerful synthwave loop: Am → F → C → G, pentatonic lead, hats + snare. */
  private startSequencer(): void {
    if (!this.ctx || !this.musicBus || this.seqTimer !== null) return;
    const BPM = 116;
    const stepDur = 60 / BPM / 2; // 8th notes
    this.seqStep = 0;
    this.seqNextTime = this.ctx.currentTime + 0.08;

    // chord roots (MIDI): Am, F, C, G
    const CHORDS = [45, 41, 48, 43]; // A2, F2, C3, G2
    const BASS_PAT = [0, -1, 12, -1, 0, -1, 7, -1]; // -1 = rest
    const PENT = [0, 3, 5, 7, 10, 12, 15, 19];
    const LEAD_PAT = [0, 2, 1, 3, 5, 3, 2, 1];

    const tick = (): void => {
      if (!this.ctx || !this.musicBus) return;
      while (this.seqNextTime < this.ctx.currentTime + 0.28) {
        const t = this.seqNextTime;
        const step = this.seqStep % 8;
        const bar = Math.floor(this.seqStep / 8) % 4;
        const root = CHORDS[bar];

        // bass (buzzy square through lowpass)
        const bOff = BASS_PAT[step];
        if (bOff >= 0) {
          this.tone('square', midi(root - 12 + bOff), t, stepDur * 0.9, 0.16, 500, this.musicBus);
        }
        // lead arp (triangle, sparkle)
        if (bar % 2 === 0 || step % 2 === 0) {
          const note = root + 24 + PENT[LEAD_PAT[step]];
          const vol = step === 0 ? 0.1 : 0.075;
          this.tone('triangle', midi(note), t, stepDur * 0.85, vol, 4200, this.musicBus);
        }
        // hats on offbeats
        if (step % 2 === 1) this.hat(t, 0.045, this.musicBus);
        // snare on beats 2 & 4
        if (step === 4) this.noiseHit(t, 0.12, 1800, 0.09, this.musicBus);

        this.seqNextTime += stepDur;
        this.seqStep++;
      }
    };
    this.seqTimer = window.setInterval(tick, 90);
    tick();
  }

  // ------------------------------------------------------------------ sfx ----

  play(name: SfxName, intensity = 1): void {
    if (!this.ctx || !this.sfxBus) return;
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    const buf = this.buffers.get(name);
    if (buf) {
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const g = this.ctx.createGain();
      g.gain.value = Math.min(1, 0.4 + intensity * 0.6);
      src.connect(g).connect(this.sfxBus);
      src.start();
      return;
    }
    this.synth(name, intensity);
  }

  // ------------------------------------------------------------ synth kit ----

  private tone(
    type: OscillatorType,
    freq: number,
    t: number,
    dur: number,
    vol: number,
    lpf: number,
    dest: AudioNode,
    slideTo?: number
  ): void {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo !== undefined) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = lpf;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(filter).connect(g).connect(dest);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  private noiseHit(t: number, dur: number, bpf: number, vol: number, dest: AudioNode): void {
    if (!this.ctx || !this.noiseBuf) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 1;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = bpf;
    filter.Q.value = 0.9;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter).connect(g).connect(dest);
    src.start(t, Math.random() * 0.3);
    src.stop(t + dur + 0.02);
  }

  private hat(t: number, vol: number, dest: AudioNode): void {
    this.noiseHit(t, 0.045, 8000, vol, dest);
  }

  /** Procedural fallback sounds — the game is fully audible with zero audio files. */
  private synth(name: SfxName, intensity: number): void {
    if (!this.ctx || !this.sfxBus) return;
    const t = this.ctx.currentTime;
    const bus = this.sfxBus;
    const v = Math.min(1, 0.5 + intensity * 0.5);

    switch (name) {
      case 'flipper':
        this.tone('square', 170, t, 0.075, 0.22, 1200, bus, 70);
        this.noiseHit(t, 0.03, 3200, 0.12, bus);
        break;
      case 'bumper': {
        this.tone('sine', 560, t, 0.14, 0.5 * v, 3000, bus, 150);
        this.tone('square', 840, t, 0.06, 0.12, 4000, bus, 320);
        this.noiseHit(t, 0.05, 5200, 0.14, bus);
        break;
      }
      case 'star':
        this.tone('triangle', 920, t, 0.16, 0.3, 6000, bus);
        this.tone('triangle', 1380, t + 0.07, 0.2, 0.28, 6000, bus);
        break;
      case 'sling':
        this.noiseHit(t, 0.09, 900, 0.4, bus);
        this.tone('sine', 240, t, 0.1, 0.32, 1000, bus, 90);
        break;
      case 'launch':
        this.tone('square', 140, t, 0.3, 0.3, 2400, bus, 900);
        this.tone('sine', 90, t, 0.28, 0.25, 800, bus, 480);
        break;
      case 'drain':
        this.tone('sawtooth', 340, t, 0.5, 0.3, 1600, bus, 48);
        this.tone('sine', 160, t, 0.5, 0.25, 900, bus, 36);
        break;
      case 'gameover': {
        const notes = [64, 60, 57, 52, 45]; // E4 C4 A3 E3 A2
        notes.forEach((n, i) => {
          this.tone('triangle', midi(n), t + i * 0.17, 0.24, 0.28, 3000, bus);
          this.tone('sine', midi(n - 12), t + i * 0.17, 0.24, 0.18, 1200, bus);
        });
        break;
      }
      case 'orbit':
        this.noiseHit(t, 0.32, 1400, 0.25, bus);
        this.tone('sine', 300, t, 0.32, 0.22, 4000, bus, 1200);
        this.tone('triangle', 660, t + 0.05, 0.25, 0.18, 5000, bus, 1320);
        break;
      case 'ramp':
        this.tone('sine', 320, t, 0.2, 0.3, 5000, bus, 1250);
        this.tone('triangle', 1240, t + 0.1, 0.22, 0.22, 6000, bus);
        break;
      case 'bonus': {
        const notes = [72, 76, 79, 84]; // C5 E5 G5 C6
        notes.forEach((n, i) => this.tone('square', midi(n), t + i * 0.08, 0.14, 0.16, 4000, bus));
        break;
      }
      case 'save':
        this.tone('triangle', 784, t, 0.14, 0.28, 5000, bus);
        this.tone('triangle', 1318, t + 0.09, 0.2, 0.28, 6000, bus);
        break;
      case 'click':
        this.tone('square', 1000, t, 0.035, 0.12, 5000, bus, 500);
        break;
    }
  }
}
