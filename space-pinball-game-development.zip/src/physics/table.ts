import Matter from 'matter-js';
import { BALL_R, PLANETS, STAR_TARGETS } from '../game/constants';

const { Bodies } = Matter;

export interface DrawSeg {
  x: number;
  y: number;
  w: number;
  h: number;
  angle: number;
}

export interface Sling {
  body: Matter.Body;
  kick: Matter.Vector; // unit direction the sling punts the ball
}

export interface TableParts {
  bodies: Matter.Body[];
  wallSegs: DrawSeg[];
  slingSegs: DrawSeg[];
  slings: Sling[];
  bumpers: Matter.Body[];
  stars: Matter.Body[];
  drain: Matter.Body;
  rampSensor: Matter.Body;
  orbitSensor: Matter.Body;
}

/** Top arc geometry (also used by the renderer). */
export const ARC = { cx: 270, cy: 300, r: 261, segR: 270, segs: 26 };

/** Plunger / spawn point (right launch lane, resting on the plunger base). */
export const SPAWN = { x: 513, y: 917 };

/** Round posts between funnel ends and flippers (drawn by the renderer). */
export const POSTS = [
  { x: 180, y: 847, r: 10 },
  { x: 360, y: 847, r: 10 },
];

/** Rectangle helper from raw center/size/angle. */
function box(
  x: number,
  y: number,
  w: number,
  h: number,
  angle: number,
  label: string,
  extra: Matter.IChamferableBodyDefinition = {}
): Matter.Body {
  return Bodies.rectangle(x, y, w, h, {
    isStatic: true,
    angle,
    label,
    friction: 0.02,
    restitution: 0.2,
    ...extra,
  });
}

/** Rotated-rectangle wall between two points. */
function seg(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  thick: number,
  label: string,
  extra: Matter.IChamferableBodyDefinition = {}
): { body: Matter.Body; draw: DrawSeg } {
  const cx = (x1 + x2) / 2;
  const cy = (y1 + y2) / 2;
  const len = Math.hypot(x2 - x1, y2 - y1);
  const angle = Math.atan2(y2 - y1, x2 - x1);
  return {
    body: box(cx, cy, len + thick, thick, angle, label, extra),
    draw: { x: cx, y: cy, w: len + thick, h: thick, angle },
  };
}

export function buildTable(): TableParts {
  const bodies: Matter.Body[] = [];
  const wallSegs: DrawSeg[] = [];
  const slingSegs: DrawSeg[] = [];

  const add = (b: Matter.Body): Matter.Body => {
    bodies.push(b);
    return b;
  };

  // ---- rounded top: half-circle (θ from π to 2π) built of chord segments ----
  const step = Math.PI / ARC.segs;
  for (let i = 0; i < ARC.segs; i++) {
    const a1 = Math.PI + i * step;
    const a2 = Math.PI + (i + 1) * step;
    const x1 = ARC.cx + Math.cos(a1) * ARC.segR;
    const y1 = ARC.cy + Math.sin(a1) * ARC.segR;
    const x2 = ARC.cx + Math.cos(a2) * ARC.segR;
    const y2 = ARC.cy + Math.sin(a2) * ARC.segR;
    const s = seg(x1, y1, x2, y2, 18, 'wall');
    add(s.body);
    wallSegs.push(s.draw);
  }

  // ---- outer walls ----
  const leftWall = box(0, 630, 18, 660, 0, 'wall');
  add(leftWall);
  wallSegs.push({ x: 0, y: 630, w: 18, h: 660, angle: 0 });

  const rightWall = box(540, 605, 18, 710, 0, 'wall');
  add(rightWall);
  wallSegs.push({ x: 540, y: 605, w: 18, h: 710, angle: 0 });

  // ---- launch-lane deflector: steep (~65°) so a rising ball leaves the lane
  //      heading up-left, tangent to the top arc. Its upper face also steers
  //      slow field balls down into the playfield — a solid one-way system. ----
  const defl = seg(489, 160, 530, 250, 14, 'wall');
  add(defl.body);
  wallSegs.push(defl.draw);

  // ---- lane divider: starts BELOW the deflected ball's exit trajectory
  //      (the gap between deflector foot and divider top is the lane exit) ----
  const divider = box(489, 583.5, 14, 677, 0, 'wall', { chamfer: { radius: 4 } });
  add(divider);
  wallSegs.push({ x: 489, y: 583.5, w: 14, h: 677, angle: 0 });

  // ---- plunger platform (the ball rests on this between launches) ----
  const plungerBase = box(513, 935, 36, 14, 0, 'wall', { restitution: 0.1 });
  add(plungerBase);
  wallSegs.push({ x: 513, y: 935, w: 36, h: 14, angle: 0 });

  // ---- left orbit lane rail ----
  const rail = box(66, 470, 10, 190, 0, 'wall');
  add(rail);
  wallSegs.push({ x: 66, y: 470, w: 10, h: 190, angle: 0 });

  // ---- left funnel: upper part is a live slingshot ----
  const lsling = seg(9, 560, 74.2, 670.4, 16, 'sling', { restitution: 0.9 });
  add(lsling.body);
  slingSegs.push(lsling.draw);
  const lfun = seg(74.2, 670.4, 172, 836, 16, 'wall');
  add(lfun.body);
  wallSegs.push(lfun.draw);

  // ---- right funnel (hangs off the divider) ----
  const rsling = seg(482, 560, 436.4, 670.4, 16, 'sling', { restitution: 0.9 });
  add(rsling.body);
  slingSegs.push(rsling.draw);
  const rfun = seg(436.4, 670.4, 368, 836, 16, 'wall');
  add(rfun.body);
  wallSegs.push(rfun.draw);

  // ---- posts bridging funnels → flippers ----
  for (const post of POSTS) {
    add(Bodies.circle(post.x, post.y, post.r, { isStatic: true, label: 'wall', restitution: 0.3, friction: 0.02 }));
  }

  // ---- slingshots ----
  const slings: Sling[] = [
    { body: lsling.body, kick: { x: 0.861, y: -0.508 } },
    { body: rsling.body, kick: { x: -0.924, y: -0.381 } },
  ];

  // ---- planet bumpers ----
  const bumpers = PLANETS.map((p, i) =>
    add(
      Bodies.circle(p.x, p.y, p.r, {
        isStatic: true,
        label: `bumper:${i}`,
        restitution: 1.4,
        friction: 0,
      })
    )
  );

  // ---- star target bank (on the lane divider) ----
  const stars = STAR_TARGETS.map((s, i) =>
    add(
      Bodies.circle(s.x, s.y, s.r, {
        isStatic: true,
        label: `star:${i}`,
        restitution: 1.2,
        friction: 0,
      })
    )
  );

  // ---- sensors (non-physical triggers) ----
  const sensor: Matter.IChamferableBodyDefinition = { isStatic: true, isSensor: true };
  const drain = add(box(270, 955, 580, 22, 0, 'drain', sensor));
  const rampSensor = add(box(360, 88, 150, 30, 0.406, 'ramp', sensor));
  const orbitSensor = add(Bodies.circle(35, 468, 22, { ...sensor, label: 'orbit' }));

  return {
    bodies,
    wallSegs,
    slingSegs,
    slings,
    bumpers,
    stars,
    drain,
    rampSensor,
    orbitSensor,
  };
}

/** The one and only ball. */
export function makeBall(): Matter.Body {
  return Bodies.circle(SPAWN.x, SPAWN.y, BALL_R, {
    label: 'ball',
    restitution: 0.42,
    friction: 0.05,
    frictionAir: 0.012,
    density: 0.0016,
    slop: 0.02,
  });
}
