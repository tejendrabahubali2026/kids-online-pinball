import Matter from 'matter-js';

const { Bodies, Body, Constraint } = Matter;

export type FlipperSide = 'left' | 'right';

const LENGTH = 78;
const HEIGHT = 26;
const PIVOT_OFFSET = 34; // distance from body center to the pivot (fat end)
const STEP = 0.3; // rad per tick — full stroke in ~4 ticks (≈65 ms), very snappy
const HOLD_EPS = 0.02;

const REST_L = 0.56; // 32° downward
const ACTIVE_L = -0.48; // flipped up
const REST_R = Math.PI - 0.56;
const ACTIVE_R = Math.PI + 0.48;

function normAngle(a: number): number {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

/**
 * A pinball flipper: a dense trapezoid pinned by a stiff constraint.
 * Rotation is driven kinematically — the angle is stepped toward the target
 * every tick while angular velocity is fed back into the physics world, so
 * the blade still punts the ball with real momentum. Rock solid, no tuning
 * instability, and the stroke completes in ~65 ms for tight controls.
 */
export class Flipper {
  readonly body: Matter.Body;
  readonly pin: Matter.Constraint;
  readonly side: FlipperSide;
  readonly pivot: Matter.Vector;
  pressed = false;
  /** 0→1 flip animation progress, for render juice */
  flipAnim = 0;

  private restAngle: number;
  private activeAngle: number;

  constructor(side: FlipperSide, pivotX: number, pivotY: number) {
    this.side = side;
    this.pivot = { x: pivotX, y: pivotY };
    this.restAngle = side === 'left' ? REST_L : REST_R;
    this.activeAngle = side === 'left' ? ACTIVE_L : ACTIVE_R;

    // fat end sits on the pivot; body extends along the rest angle
    const cx = pivotX + Math.cos(this.restAngle) * PIVOT_OFFSET;
    const cy = pivotY + Math.sin(this.restAngle) * PIVOT_OFFSET;

    this.body = Bodies.trapezoid(cx, cy, LENGTH, HEIGHT, 0.42, {
      label: side === 'left' ? 'flipperL' : 'flipperR',
      density: 0.09,
      friction: 0.2,
      frictionAir: 0.02,
      restitution: 0.15,
      chamfer: { radius: 6 },
    });
    Body.setAngle(this.body, this.restAngle);

    const localPivot = this.side === 'left' ? { x: -PIVOT_OFFSET, y: 0 } : { x: PIVOT_OFFSET, y: 0 };
    this.pin = Constraint.create({
      pointA: this.pivot,
      bodyB: this.body,
      pointB: localPivot,
      length: 0,
      stiffness: 0.9,
      damping: 0.1,
    });
  }

  setPressed(p: boolean): void {
    if (p === this.pressed) return;
    this.pressed = p;
  }

  /** Call every physics tick. */
  update(): void {
    const target = this.pressed ? this.activeAngle : this.restAngle;
    const err = normAngle(target - this.body.angle);

    let w = 0;
    if (Math.abs(err) <= HOLD_EPS) {
      // hard hold — keeps the blade rock steady under ball impacts
      if (this.body.angle !== target || this.body.angularVelocity !== 0) {
        Body.setAngle(this.body, target);
        Body.setAngularVelocity(this.body, 0);
      }
    } else {
      w = Math.sign(err) * Math.min(STEP, Math.abs(err));
      Body.setAngle(this.body, this.body.angle + w);
      Body.setAngularVelocity(this.body, w); // momentum for ball contacts
    }

    // animation param for rendering (0 = rest, 1 = fully flipped)
    const travel = Math.abs(this.activeAngle - this.restAngle);
    const prog = Math.abs(normAngle(this.body.angle - this.restAngle)) / travel;
    this.flipAnim = Math.max(0, Math.min(1, prog));
  }

  /** World-space tip position (for render juice). */
  tip(): Matter.Vector {
    const a = this.body.angle;
    return {
      x: this.body.position.x + Math.cos(a) * (LENGTH / 2),
      y: this.body.position.y + Math.sin(a) * (LENGTH / 2),
    };
  }
}
