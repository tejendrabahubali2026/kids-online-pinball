import type { HiScore } from '../game/storage';

export interface UICallbacks {
  onPlay: () => void;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  onPause: () => void;
  onMute: () => void;
  onSaveName: (name: string) => void;
}

const ICONS = {
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.14v13.72a1 1 0 0 0 1.52.86l11-6.86a1 1 0 0 0 0-1.72l-11-6.86A1 1 0 0 0 8 5.14Z"/></svg>',
  pause:
    '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1.2"/><rect x="14" y="4" width="4" height="16" rx="1.2"/></svg>',
  sound:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H3a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h3l5 4V5Z" fill="currentColor" stroke="none"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>',
  muted:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H3a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h3l5 4V5Z" fill="currentColor" stroke="none"/><line x1="22" y1="9" x2="16" y2="15"/><line x1="16" y1="9" x2="22" y2="15"/></svg>',
  restart:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 2.64-6.36"/><polyline points="3 4 3.4 9 8.4 8.6"/></svg>',
  home:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/></svg>',
};

function fmt(n: number): string {
  return n.toLocaleString('en-US');
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] ?? c);
}

function tableRows(list: HiScore[], highlight = -1): string {
  if (list.length === 0) {
    return '<li class="empty">No scores yet — be the first Space Pilot!</li>';
  }
  return list
    .map(
      (e, i) =>
        `<li class="${i === highlight ? 'hl' : ''}"><span class="rank">${i + 1}</span><span class="name">${escapeHtml(
          e.name
        )}</span><span class="pts">${fmt(e.score)}</span></li>`
    )
    .join('');
}

export class ScreenManager {
  private root: HTMLDivElement;
  private hud: HTMLDivElement;
  private scoreEl: HTMLDivElement;
  private bestEl: HTMLDivElement;
  private ballsEl: HTMLDivElement;
  private comboEl: HTMLDivElement;
  private toastEl: HTMLDivElement;
  private hintEl: HTMLDivElement;
  private muteBtn: HTMLButtonElement;

  private startScr: HTMLDivElement;
  private startTable: HTMLUListElement;
  private pauseScr: HTMLDivElement;
  private overScr: HTMLDivElement;
  private finalScoreEl: HTMLDivElement;
  private newBestEl: HTMLDivElement;
  private nameRow: HTMLDivElement;
  private nameInput: HTMLInputElement;
  private overTable: HTMLUListElement;

  private toastTimer = 0;
  private countRaf = 0;
  private lastScore = 0;

  constructor(container: HTMLElement, cb: UICallbacks) {
    this.root = document.createElement('div');
    this.root.className = 'spb-ui';
    this.root.innerHTML = `
      <div class="spb-hud">
        <div class="hud-block hud-left">
          <div class="hud-label">SCORE</div>
          <div class="hud-score">0</div>
          <div class="hud-best">BEST 0</div>
        </div>
        <div class="hud-combo"></div>
        <div class="hud-block hud-right">
          <div class="hud-balls"></div>
          <div class="hud-buttons">
            <button class="icon-btn js-pause" aria-label="Pause (P)">${ICONS.pause}</button>
            <button class="icon-btn js-mute" aria-label="Mute (M)">${ICONS.sound}</button>
          </div>
        </div>
      </div>
      <div class="spb-toast"></div>
      <div class="spb-hint"></div>

      <div class="spb-screen spb-start active">
        <div class="orb orb-a"></div>
        <div class="orb orb-b"></div>
        <div class="panel start-panel">
          <div class="kicker">A KID-FRIENDLY COSMIC ARCADE</div>
          <h1 class="title"><span>SPACE</span><span class="title-mid">PINBALL</span><span class="title-blast">BLAST</span></h1>
          <button class="btn btn-primary js-play">${ICONS.play}<span>PLAY</span></button>
          <div class="controls">
            <div class="ctl"><span class="keys"><kbd>◀</kbd><kbd>▶</kbd></span><span>Flippers</span></div>
            <div class="ctl"><span class="keys"><kbd class="wide">SPACE</kbd></span><span>Hold to launch</span></div>
            <div class="ctl"><span class="keys"><kbd>P</kbd></span><span>Pause</span></div>
            <div class="ctl touch"><span class="keys"><kbd class="wide">TOUCH</kbd></span><span>Left / right half = flippers · hold right side to launch</span></div>
          </div>
          <div class="hs">
            <div class="hs-title">TOP SPACE PILOTS</div>
            <ul class="hs-list js-start-table"></ul>
          </div>
        </div>
      </div>

      <div class="spb-screen spb-pause">
        <div class="panel">
          <h2 class="h-big">PAUSED</h2>
          <button class="btn btn-primary js-resume">${ICONS.play}<span>RESUME</span></button>
          <button class="btn btn-ghost js-restart">${ICONS.restart}<span>RESTART</span></button>
          <button class="btn btn-ghost js-quit">${ICONS.home}<span>MAIN MENU</span></button>
          <div class="note">P / ESC to resume</div>
        </div>
      </div>

      <div class="spb-screen spb-over">
        <div class="panel">
          <h2 class="h-big h-danger">GAME OVER</h2>
          <div class="final-label">FINAL SCORE</div>
          <div class="final-score js-final">0</div>
          <div class="new-best js-newbest">★ NEW HIGH SCORE ★</div>
          <div class="name-row js-namerow">
            <input class="name-input js-name" maxlength="10" placeholder="YOUR NAME" autocomplete="off" spellcheck="false" />
            <button class="btn btn-small js-save">SAVE</button>
          </div>
          <div class="hs">
            <div class="hs-title">TOP SPACE PILOTS</div>
            <ul class="hs-list js-over-table"></ul>
          </div>
          <button class="btn btn-primary js-again">${ICONS.restart}<span>PLAY AGAIN</span></button>
          <button class="btn btn-ghost js-menu">${ICONS.home}<span>MAIN MENU</span></button>
        </div>
      </div>
    `;
    container.appendChild(this.root);

    const q = <T extends HTMLElement>(sel: string): T => {
      const el = this.root.querySelector<T>(sel);
      if (!el) throw new Error(`UI element missing: ${sel}`);
      return el;
    };

    this.hud = q('.spb-hud');
    this.scoreEl = q('.hud-score');
    this.bestEl = q('.hud-best');
    this.ballsEl = q('.hud-balls');
    this.comboEl = q('.hud-combo');
    this.toastEl = q('.spb-toast');
    this.hintEl = q('.spb-hint');
    this.muteBtn = q('.js-mute');
    this.startScr = q('.spb-start');
    this.startTable = q('.js-start-table');
    this.pauseScr = q('.spb-pause');
    this.overScr = q('.spb-over');
    this.finalScoreEl = q('.js-final');
    this.newBestEl = q('.js-newbest');
    this.nameRow = q('.js-namerow');
    this.nameInput = q('.js-name');
    this.overTable = q('.js-over-table');

    q<HTMLButtonElement>('.js-play').addEventListener('click', cb.onPlay);
    q<HTMLButtonElement>('.js-resume').addEventListener('click', cb.onResume);
    q<HTMLButtonElement>('.js-restart').addEventListener('click', cb.onRestart);
    q<HTMLButtonElement>('.js-quit').addEventListener('click', cb.onMenu);
    q<HTMLButtonElement>('.js-pause').addEventListener('click', cb.onPause);
    this.muteBtn.addEventListener('click', cb.onMute);
    q<HTMLButtonElement>('.js-again').addEventListener('click', cb.onRestart);
    q<HTMLButtonElement>('.js-menu').addEventListener('click', cb.onMenu);

    const save = (): void => cb.onSaveName(this.nameInput.value || 'PLAYER');
    q<HTMLButtonElement>('.js-save').addEventListener('click', save);
    this.nameInput.addEventListener('keydown', (e) => {
      e.stopPropagation(); // keep game hotkeys quiet while typing
      if (e.key === 'Enter') save();
    });

    this.setBalls(3);
  }

  private show(screen: HTMLDivElement | null): void {
    for (const s of [this.startScr, this.pauseScr, this.overScr]) s.classList.remove('active');
    if (screen) screen.classList.add('active');
  }

  showStart(list: HiScore[], best: number): void {
    this.startTable.innerHTML = tableRows(list);
    this.bestEl.textContent = `BEST ${fmt(best)}`;
    this.hud.classList.remove('in-game');
    this.setHint(null);
    this.show(this.startScr);
  }

  enterGame(ballsLeft: number, best: number): void {
    this.hud.classList.add('in-game');
    this.show(null);
    this.setBalls(ballsLeft);
    this.lastScore = 0;
    this.bestEl.textContent = `BEST ${fmt(best)}`;
  }

  showPause(on: boolean): void {
    this.show(on ? this.pauseScr : null);
  }

  showGameOver(score: number, list: HiScore[], qualifies: boolean): void {
    this.hud.classList.remove('in-game');
    this.show(this.overScr);
    this.overTable.innerHTML = tableRows(list);
    this.newBestEl.classList.toggle('show', qualifies);
    this.nameRow.classList.toggle('show', qualifies);
    if (qualifies) {
      this.nameInput.value = '';
      window.setTimeout(() => this.nameInput.focus(), 350);
    }
    this.countUp(score);
  }

  showGameOverSaved(list: HiScore[], rank: number): void {
    this.nameRow.classList.remove('show');
    this.overTable.innerHTML = tableRows(list, rank);
  }

  private countUp(target: number): void {
    cancelAnimationFrame(this.countRaf);
    const t0 = performance.now();
    const dur = Math.min(1200, 300 + target * 0.02);
    const tick = (now: number): void => {
      const t = Math.min(1, (now - t0) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      this.finalScoreEl.textContent = fmt(Math.round(target * eased));
      if (t < 1) this.countRaf = requestAnimationFrame(tick);
    };
    this.countRaf = requestAnimationFrame(tick);
  }

  setScore(score: number): void {
    this.scoreEl.textContent = fmt(score);
    if (score > this.lastScore) {
      this.scoreEl.classList.remove('pop');
      void this.scoreEl.offsetWidth; // restart animation
      this.scoreEl.classList.add('pop');
    }
    this.lastScore = score;
  }

  setBalls(left: number): void {
    this.ballsEl.innerHTML = '';
    for (let i = 0; i < 3; i++) {
      const pip = document.createElement('span');
      pip.className = `ball-pip${i < left ? '' : ' spent'}`;
      this.ballsEl.appendChild(pip);
    }
  }

  setCombo(mult: number): void {
    if (mult >= 2) {
      this.comboEl.textContent = `COMBO ×${mult}`;
      this.comboEl.classList.add('show');
      this.comboEl.classList.remove('pop');
      void this.comboEl.offsetWidth;
      this.comboEl.classList.add('pop');
    } else {
      this.comboEl.classList.remove('show');
    }
  }

  toast(text: string, ms = 1500): void {
    window.clearTimeout(this.toastTimer);
    this.toastEl.textContent = text;
    this.toastEl.classList.remove('show');
    void this.toastEl.offsetWidth;
    this.toastEl.classList.add('show');
    this.toastTimer = window.setTimeout(() => this.toastEl.classList.remove('show'), ms);
  }

  setHint(text: string | null): void {
    if (text) {
      this.hintEl.textContent = text;
      this.hintEl.classList.add('show');
    } else {
      this.hintEl.classList.remove('show');
    }
  }

  syncMute(muted: boolean): void {
    this.muteBtn.innerHTML = muted ? ICONS.muted : ICONS.sound;
    this.muteBtn.classList.toggle('muted', muted);
  }

  destroy(): void {
    cancelAnimationFrame(this.countRaf);
    window.clearTimeout(this.toastTimer);
    this.root.remove();
  }
}
