/**
 * Space Pinball Blast — shared design constants.
 * All physics / layout coordinates are expressed in VIRTUAL units.
 * The renderer scales this virtual space to fit the device screen.
 */

export const VIEW_W = 540; // virtual playfield width
export const VIEW_H = 960; // virtual playfield height

export const BALL_R = 11;
export const BALLS_PER_GAME = 3;
export const MAX_BALL_SPEED = 38;
export const LAUNCH_MIN = 27; // softest launch still reaches the lane deflector
export const LAUNCH_MAX = 36; // full power rides the whole top arc
export const CHARGE_TIME_MS = 950; // hold-to-full-power time

export const COMBO_WINDOW_MS = 3000;
export const COMBO_MAX = 8;
export const BALL_SAVE_MS = 4500; // kid-friendly ball saver after launch

export const SCORE = {
  bumper: 100,
  star: 250,
  sling: 50,
  ramp: 500,
  orbit: 750,
  starBankBonus: 1000,
} as const;

/** Neon palette (canvas + css keep these in sync). */
export const COLORS = {
  bg0: '#050514',
  bg1: '#0d0b2e',
  wall: '#7b5cff',
  wallGlow: 'rgba(123,92,255,0.55)',
  lane: '#38e8ff',
  sling: '#ff4fa3',
  gate: '#ffd257',
  flipper: '#39ffb2',
  flipperCore: '#eafffb',
  ball: '#f4f7ff',
  orbit: '#38e8ff',
  ramp: '#b26bff',
} as const;

export interface PlanetDef {
  id: string;
  x: number;
  y: number;
  r: number;
  base: string; // main gradient color
  dark: string; // shade color
  glow: string; // halo color
  ring: boolean; // draw a saturn-style ring
  name: string;
}

export const PLANETS: PlanetDef[] = [
  {
    id: 'mars',
    x: 270,
    y: 302,
    r: 38,
    base: '#ff5a3c',
    dark: '#8f1e0e',
    glow: 'rgba(255,106,60,0.75)',
    ring: false,
    name: 'Mars',
  },
  {
    id: 'saturn',
    x: 163,
    y: 398,
    r: 33,
    base: '#c98bff',
    dark: '#5a2e99',
    glow: 'rgba(190,120,255,0.75)',
    ring: true,
    name: 'Saturn',
  },
  {
    id: 'nova',
    x: 377,
    y: 398,
    r: 33,
    base: '#39c6ff',
    dark: '#0c4d8f',
    glow: 'rgba(70,190,255,0.75)',
    ring: false,
    name: 'Nova',
  },
];

export interface StarTargetDef {
  x: number;
  y: number;
  r: number;
}

export const STAR_TARGETS: StarTargetDef[] = [
  { x: 466, y: 430, r: 14 },
  { x: 466, y: 502, r: 14 },
  { x: 466, y: 574, r: 14 },
];

/** localStorage key for the top-10 high-score table */
export const HISCORE_KEY = 'spb_highscores_v1';
export const HISCORE_MAX = 10;
