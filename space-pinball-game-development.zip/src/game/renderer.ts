import type Matter from 'matter-js';
import { COLORS, PLANETS, STAR_TARGETS, VIEW_H, VIEW_W } from './constants';
import { ARC, POSTS } from '../physics/table';
import type { DrawSeg } from '../physics/table';
import type { Flipper } from '../physics/flippers';

const NEVER = -9999;

/** Everything the renderer needs each frame — provided by the Game. */
export interface GameView {
  time: number;
  ball: Matter.Body | null;
  trail: { x: number; y: number }[];
  alive: boolean;
  flipL: Flipper;
  flipR: Flipper;
  wallSegs: DrawSeg[];
  slingSegs: DrawSeg[];
  ballState: 'idle' | 'ready' | 'charging' | 'live';
  charge: number; // 0..1 launch power
  bumperFlash: number[]; // absolute time of last hit per bumper
  starFlash: number[];
  starsLit: boolean[];
  slingFlash: number[];
  rampFlash: number;
  orbitFlash: number;
  drainFlash: number;
  shakeX: number;
  shakeY: number;
  particles: { draw(ctx: CanvasRenderingContext2D): void; drawPopups(ctx: CanvasRenderingContext2D): void };
}

interface Twinkle {
  x: number;
  y: number;
  r: number;
  phase: number;
  speed: number;
  hue: string;
}

function mulberry32(seed: number): () => number {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function starPath(ctx: CanvasRenderingContext2D, cx: number, cy: number, ro: number, ri: number, rot: number): void {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? ro : ri;
    const a = rot + (i / 10) * Math.PI * 2 - Math.PI / 2;
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

export class Renderer {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private bg: HTMLCanvasElement | null = null;
  private twinkles: Twinkle[] = [];
  scale = 1;
  offX = 0;
  offY = 0;
  private dpr = 1;
  private cssW = 0;
  private cssH = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas 2D not supported');
    this.ctx = ctx;

    const rnd = mulberry32(1337);
    const hues = ['#ffffff', '#9fd8ff', '#ffd9a0', '#e7b6ff'];
    for (let i = 0; i < 120; i++) {
      this.twinkles.push({
        x: 14 + rnd() * (VIEW_W - 28),
        y: 40 + rnd() * (VIEW_H - 60),
        r: 0.5 + rnd() * 1.5,
        phase: rnd() * Math.PI * 2,
        speed: 0.6 + rnd() * 2.4,
        hue: hues[Math.floor(rnd() * hues.length)],
      });
    }
    this.resize();
  }

  resize(): void {
    const parent = this.canvas.parentElement;
    this.cssW = parent ? parent.clientWidth : window.innerWidth;
    this.cssH = parent ? parent.clientHeight : window.innerHeight;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(this.cssW * this.dpr);
    this.canvas.height = Math.round(this.cssH * this.dpr);
    this.canvas.style.width = `${this.cssW}px`;
    this.canvas.style.height = `${this.cssH}px`;
    this.scale = Math.min(this.cssW / VIEW_W, this.cssH / VIEW_H);
    this.offX = (this.cssW - VIEW_W * this.scale) / 2;
    this.offY = (this.cssH - VIEW_H * this.scale) / 2;
    this.buildBackground();
  }

  /** Convert client (page) coordinates to virtual playfield coordinates. */
  toVirtual(clientX: number, clientY: number): { x: number; y: number } {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: (clientX - rect.left - this.offX) / this.scale,
      y: (clientY - rect.top - this.offY) / this.scale,
    };
  }

  // ------------------------------------------------------------- background

  private buildBackground(): void {
    const w = this.canvas.width;
    const h = this.canvas.height;
    const bg = document.createElement('canvas');
    bg.width = w;
    bg.height = h;
    const c = bg.getContext('2d');
    if (!c) return;

    // deep space gradient
    const g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#070720');
    g.addColorStop(0.45, COLORS.bg1);
    g.addColorStop(1, '#04030f');
    c.fillStyle = g;
    c.fillRect(0, 0, w, h);

    const rnd = mulberry32(42);

    // nebulas
    const nebs = [
      { x: 0.22, y: 0.24, r: 0.5, col: 'rgba(123,92,255,0.16)' },
      { x: 0.85, y: 0.6, r: 0.45, col: 'rgba(56,232,255,0.10)' },
      { x: 0.5, y: 0.9, r: 0.55, col: 'rgba(255,79,163,0.10)' },
      { x: 0.75, y: 0.1, r: 0.35, col: 'rgba(255,210,87,0.07)' },
    ];
    c.globalCompositeOperation = 'screen';
    for (const n of nebs) {
      const rg = c.createRadialGradient(n.x * w, n.y * h, 0, n.x * w, n.y * h, n.r * Math.min(w, h));
      rg.addColorStop(0, n.col);
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = rg;
      c.fillRect(0, 0, w, h);
    }

    // distant stars
    for (let i = 0; i < 220; i++) {
      const x = rnd() * w;
      const y = rnd() * h;
      const r = rnd() * 1.4 + 0.2;
      c.globalAlpha = 0.25 + rnd() * 0.65;
      c.fillStyle = rnd() > 0.85 ? '#9fd8ff' : '#ffffff';
      c.beginPath();
      c.arc(x, y, r * this.dpr * 0.75, 0, Math.PI * 2);
      c.fill();
    }
    c.globalAlpha = 1;
    c.globalCompositeOperation = 'source-over';
    this.bg = bg;
  }

  private tablePath(): Path2D {
    const p = new Path2D();
    p.moveTo(9, VIEW_H + 2);
    p.lineTo(9, 302);
    p.arc(ARC.cx, ARC.cy, ARC.r, Math.PI, Math.PI * 2, false);
    p.lineTo(531, 302);
    p.lineTo(531, VIEW_H + 2);
    p.closePath();
    return p;
  }

  // ------------------------------------------------------------------ draw

  draw(v: GameView): void {
    const ctx = this.ctx;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);

    // full-bleed background
    if (this.bg) ctx.drawImage(this.bg, 0, 0, this.cssW, this.cssH);
    else {
      ctx.fillStyle = COLORS.bg0;
      ctx.fillRect(0, 0, this.cssW, this.cssH);
    }

    // world transform (+ screen shake)
    ctx.save();
    ctx.translate(this.offX + v.shakeX * this.scale, this.offY + v.shakeY * this.scale);
    ctx.scale(this.scale, this.scale);

    // table surface
    const tp = this.tablePath();
    const felt = ctx.createLinearGradient(0, 0, 0, VIEW_H);
    felt.addColorStop(0, 'rgba(16,12,52,0.94)');
    felt.addColorStop(0.5, 'rgba(10,8,38,0.95)');
    felt.addColorStop(1, 'rgba(14,9,44,0.96)');
    ctx.fillStyle = felt;
    ctx.fill(tp);
    // outer glow frame
    ctx.save();
    ctx.strokeStyle = 'rgba(123,92,255,0.4)';
    ctx.lineWidth = 3;
    ctx.shadowColor = COLORS.wallGlow;
    ctx.shadowBlur = 16;
    ctx.stroke(tp);
    ctx.restore();

    // twinkling in-table stars
    ctx.save();
    ctx.clip(tp);
    for (const t of this.twinkles) {
      const a = 0.25 + 0.55 * (0.5 + 0.5 * Math.sin(v.time * t.speed + t.phase));
      ctx.globalAlpha = a;
      ctx.fillStyle = t.hue;
      ctx.beginPath();
      ctx.arc(t.x, t.y, t.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.restore();

    this.drawSensorsArt(ctx, v);
    this.drawWalls(ctx, v);
    this.drawLaneCues(ctx, v);
    this.drawPlanets(ctx, v);
    this.drawStars(ctx, v);
    this.drawFlipper(ctx, v.flipL, v.time);
    this.drawFlipper(ctx, v.flipR, v.time);
    this.drawPlunger(ctx, v);
    this.drawBall(ctx, v);

    v.particles.draw(ctx);
    v.particles.drawPopups(ctx);

    // drain flash vignette
    const drainAge = v.time - v.drainFlash;
    if (drainAge < 0.6) {
      const a = (1 - drainAge / 0.6) * 0.45;
      const rg = ctx.createRadialGradient(270, 480, 200, 270, 480, 620);
      rg.addColorStop(0, 'rgba(255,60,90,0)');
      rg.addColorStop(1, `rgba(255,60,90,${a})`);
      ctx.fillStyle = rg;
      ctx.fillRect(-30, -30, VIEW_W + 60, VIEW_H + 60);
    }

    ctx.restore();
  }

  // ---------------------------------------------------------------- pieces

  private drawWalls(ctx: CanvasRenderingContext2D, v: GameView): void {
    for (const s of v.wallSegs) {
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(s.angle);
      const r = Math.min(7, s.h / 2);
      ctx.beginPath();
      ctx.roundRect(-s.w / 2, -s.h / 2, s.w, s.h, r);
      ctx.fillStyle = 'rgba(24,18,64,0.96)';
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = 'rgba(139,117,255,0.85)';
      ctx.stroke();
      ctx.restore();
    }
    // round posts between the funnels and flippers
    for (const post of POSTS) {
      ctx.beginPath();
      ctx.arc(post.x, post.y, post.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(24,18,64,0.96)';
      ctx.fill();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = COLORS.lane;
      ctx.shadowColor = COLORS.lane;
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.arc(post.x - 2.5, post.y - 2.5, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      ctx.fill();
    }

    // slingshots pulse hot pink
    for (let i = 0; i < v.slingSegs.length; i++) {
      const s = v.slingSegs[i];
      const flashAge = v.time - (v.slingFlash[i] ?? NEVER);
      const glow = flashAge < 0.25 ? 1 - flashAge / 0.25 : 0;
      const pulse = 0.5 + 0.5 * Math.sin(v.time * 4 + i * 2);
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(s.angle);
      ctx.beginPath();
      ctx.roundRect(-s.w / 2, -s.h / 2, s.w, s.h, 8);
      ctx.fillStyle = `rgba(90,14,58,${0.9})`;
      ctx.fill();
      ctx.lineWidth = 2.5 + glow * 2;
      ctx.shadowColor = COLORS.sling;
      ctx.shadowBlur = 8 + glow * 22 + pulse * 4;
      ctx.strokeStyle = glow > 0 ? '#ffb8dd' : COLORS.sling;
      ctx.stroke();
      // chevron strip
      ctx.shadowBlur = 0;
      ctx.fillStyle = `rgba(255,255,255,${0.25 + glow * 0.6})`;
      const n = Math.floor(s.w / 26);
      for (let k = 0; k < n; k++) {
        const x = -s.w / 2 + 16 + k * 26;
        ctx.beginPath();
        ctx.moveTo(x - 5, 5);
        ctx.lineTo(x, -5);
        ctx.lineTo(x + 5, 5);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }
  }

  private drawSensorsArt(ctx: CanvasRenderingContext2D, v: GameView): void {
    // orbit lane diamonds
    const orbitAge = v.time - v.orbitFlash;
    const oGlow = orbitAge < 0.5 ? 1 - orbitAge / 0.5 : 0;
    for (let i = 0; i < 3; i++) {
      const y = 420 + i * 46;
      const pulse = 0.35 + 0.3 * Math.sin(v.time * 3 - i * 0.8);
      ctx.save();
      ctx.translate(35, y);
      ctx.rotate(Math.PI / 4);
      const a = Math.min(1, pulse + oGlow * 0.8);
      ctx.fillStyle = `rgba(56,232,255,${a * 0.75})`;
      ctx.shadowColor = COLORS.orbit;
      ctx.shadowBlur = 6 + oGlow * 18;
      const s = 5 + oGlow * 3;
      ctx.fillRect(-s / 2, -s / 2, s, s);
      ctx.restore();
    }

    // ramp wormhole (top arc)
    const rampAge = v.time - v.rampFlash;
    const rGlow = rampAge < 0.5 ? 1 - rampAge / 0.5 : 0;
    ctx.save();
    ctx.translate(372, 96);
    ctx.rotate(v.time * 1.4);
    ctx.strokeStyle = `rgba(178,107,255,${0.5 + rGlow * 0.5})`;
    ctx.shadowColor = COLORS.ramp;
    ctx.shadowBlur = 8 + rGlow * 20;
    for (let ring = 0; ring < 2; ring++) {
      ctx.lineWidth = 2.5 - ring * 0.8;
      ctx.beginPath();
      const rr = 15 - ring * 5 + rGlow * 4;
      ctx.arc(0, 0, rr, ring, ring + Math.PI * 1.5);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawLaneCues(ctx: CanvasRenderingContext2D, v: GameView): void {
    // chasing arrows in the launch lane while the ball is ready/charging
    const active = v.ballState === 'ready' || v.ballState === 'charging';
    ctx.save();
    for (let i = 0; i < 4; i++) {
      const speed = active ? 170 : 60;
      const span = 320;
      const y = 880 - ((v.time * speed + i * 80) % span);
      const a = active ? 0.85 : 0.3;
      ctx.fillStyle = `rgba(56,232,255,${a * (1 - i * 0.16)})`;
      ctx.beginPath();
      ctx.moveTo(505, y + 10);
      ctx.lineTo(513, y);
      ctx.lineTo(521, y + 10);
      ctx.lineTo(521, y + 5);
      ctx.lineTo(513, y - 5);
      ctx.lineTo(505, y + 5);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // power meter riding the right wall
    if (v.ballState === 'charging' || v.charge > 0) {
      const mx = 534;
      const mw = 13;
      const my = 660;
      const mh = 250;
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(mx, my, mw, mh, 6);
      ctx.fillStyle = 'rgba(10,10,30,0.85)';
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = 'rgba(56,232,255,0.5)';
      ctx.stroke();
      const fillH = mh * Math.min(1, v.charge);
      const g = ctx.createLinearGradient(0, my + mh, 0, my);
      g.addColorStop(0, '#39ffb2');
      g.addColorStop(0.55, '#ffd257');
      g.addColorStop(1, '#ff4f6b');
      ctx.fillStyle = g;
      ctx.shadowColor = '#ffd257';
      ctx.shadowBlur = v.charge > 0.97 ? 16 : 6;
      ctx.beginPath();
      ctx.roundRect(mx + 2, my + mh - fillH + (fillH > 6 ? 0 : 0), mw - 4, Math.max(4, fillH - 2), 4);
      ctx.fill();
      ctx.restore();
    }
  }

  private drawPlanets(ctx: CanvasRenderingContext2D, v: GameView): void {
    for (let i = 0; i < PLANETS.length; i++) {
      const p = PLANETS[i];
      const age = v.time - (v.bumperFlash[i] ?? NEVER);
      const hit = age < 0.3 ? 1 - age / 0.3 : 0;
      const breathe = 1 + Math.sin(v.time * 2 + i * 2.1) * 0.015;
      const sx = (1 + hit * 0.22) * breathe;
      const sy = (1 - hit * 0.14) * breathe;

      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.scale(sx, sy);

      // halo
      ctx.beginPath();
      ctx.arc(0, 0, p.r + 4 + hit * 6, 0, Math.PI * 2);
      ctx.strokeStyle = p.glow;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = p.glow;
      ctx.shadowBlur = 14 + hit * 26 + 4 * Math.sin(v.time * 3 + i);
      ctx.globalAlpha = 0.65 + hit * 0.35;
      ctx.stroke();
      ctx.globalAlpha = 1;

      // sphere
      const g = ctx.createRadialGradient(-p.r * 0.38, -p.r * 0.42, p.r * 0.15, 0, 0, p.r);
      g.addColorStop(0, '#ffffff');
      g.addColorStop(0.18, p.base);
      g.addColorStop(1, p.dark);
      ctx.beginPath();
      ctx.arc(0, 0, p.r, 0, Math.PI * 2);
      ctx.shadowBlur = 20 + hit * 25;
      ctx.shadowColor = p.glow;
      ctx.fillStyle = g;
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.save();
      ctx.clip();
      if (p.id === 'mars') {
        ctx.fillStyle = 'rgba(140,40,16,0.5)';
        ctx.beginPath();
        ctx.arc(7, 6, p.r * 0.24, 0, Math.PI * 2);
        ctx.arc(-12, 12, p.r * 0.16, 0, Math.PI * 2);
        ctx.arc(12, -14, p.r * 0.13, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.id === 'nova') {
        ctx.strokeStyle = 'rgba(255,255,255,0.45)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, p.r * 0.55, v.time * 1.3, v.time * 1.3 + 2.4);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, 0, p.r * 0.78, -v.time * 0.9, -v.time * 0.9 + 1.6);
        ctx.stroke();
      } else {
        ctx.fillStyle = 'rgba(90,46,153,0.55)';
        ctx.beginPath();
        ctx.arc(-8, 8, p.r * 0.2, 0, Math.PI * 2);
        ctx.arc(10, 2, p.r * 0.14, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // saturn ring
      if (p.ring) {
        ctx.save();
        ctx.rotate(-0.42);
        ctx.lineWidth = 5;
        ctx.strokeStyle = 'rgba(255,215,140,0.85)';
        ctx.shadowColor = 'rgba(255,215,140,0.8)';
        ctx.shadowBlur = 10 + hit * 14;
        ctx.beginPath();
        ctx.ellipse(0, 0, p.r * 1.55, p.r * 0.5, 0, Math.PI * 1.05, Math.PI * 1.95);
        ctx.stroke();
        ctx.restore();
      }
      ctx.restore();
    }
  }

  private drawStars(ctx: CanvasRenderingContext2D, v: GameView): void {
    for (let i = 0; i < STAR_TARGETS.length; i++) {
      const s = STAR_TARGETS[i];
      const lit = v.starsLit[i];
      const age = v.time - (v.starFlash[i] ?? NEVER);
      const hit = age < 0.35 ? 1 - age / 0.35 : 0;
      const scale = 1 + hit * 0.5;
      const rot = hit > 0 ? (age * 4) % Math.PI : Math.sin(v.time * 1.5 + i) * 0.1;

      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(rot);
      ctx.scale(scale, scale);
      starPath(ctx, 0, 0, s.r, s.r * 0.45, 0);
      if (lit || hit > 0) {
        ctx.fillStyle = hit > 0 ? '#fff3b0' : '#ffd257';
        ctx.shadowColor = '#ffd257';
        ctx.shadowBlur = 12 + hit * 22;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.lineWidth = 1.6;
        ctx.strokeStyle = '#fff8dd';
        ctx.stroke();
      } else {
        ctx.fillStyle = 'rgba(70,70,110,0.7)';
        ctx.fill();
        ctx.lineWidth = 2;
        const pulse = 0.4 + 0.3 * Math.sin(v.time * 2.6 + i * 1.7);
        ctx.strokeStyle = `rgba(255,210,87,${pulse})`;
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  private drawFlipper(ctx: CanvasRenderingContext2D, f: Flipper, time: number): void {
    const verts = f.body.vertices;
    ctx.save();
    // pivot cap
    ctx.beginPath();
    ctx.moveTo(verts[0].x, verts[0].y);
    for (let i = 1; i < verts.length; i++) ctx.lineTo(verts[i].x, verts[i].y);
    ctx.closePath();
    const grad = ctx.createLinearGradient(f.pivot.x, f.pivot.y, f.tip().x, f.tip().y);
    grad.addColorStop(0, '#0c5c40');
    grad.addColorStop(1, '#12a474');
    ctx.fillStyle = grad;
    ctx.shadowColor = COLORS.flipper;
    ctx.shadowBlur = 10 + f.flipAnim * 14;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = COLORS.flipper;
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = COLORS.flipperCore;
    ctx.globalAlpha = 0.8;
    ctx.stroke();
    ctx.globalAlpha = 1;
    // pivot hub
    ctx.beginPath();
    ctx.arc(f.pivot.x, f.pivot.y, 8, 0, Math.PI * 2);
    ctx.fillStyle = '#0b3325';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = COLORS.flipper;
    ctx.stroke();
    // motion streak while flipping
    if (f.flipAnim > 0.05 && f.flipAnim < 0.98) {
      const dir = f.side === 'left' ? 1 : -1;
      const a0 = f.side === 'left' ? 0.56 : Math.PI - 0.56;
      const a1 = f.body.angle;
      ctx.beginPath();
      ctx.arc(f.pivot.x, f.pivot.y, 80, Math.min(a0, a1), Math.max(a0, a1));
      ctx.arc(f.pivot.x, f.pivot.y, 30, Math.max(a0, a1), Math.min(a0, a1), true);
      ctx.closePath();
      ctx.fillStyle = `rgba(57,255,178,${0.13 + 0.1 * Math.sin(time * 30) * dir * dir})`;
      ctx.fill();
    }
    ctx.restore();
  }

  private drawPlunger(ctx: CanvasRenderingContext2D, v: GameView): void {
    const cx = 513;
    const c = v.ballState === 'charging' ? v.charge : 0;
    const plateY = 928 + c * 14; // spring compressed by charge

    ctx.save();
    // base block
    ctx.beginPath();
    ctx.roundRect(500, 946, 26, 8, 3);
    ctx.fillStyle = '#241d55';
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = COLORS.lane;
    ctx.stroke();

    // coil
    ctx.beginPath();
    const coils = 5;
    const yTop = plateY + 2;
    const y0 = 946;
    ctx.moveTo(cx, yTop);
    for (let i = 0; i < coils * 2; i++) {
      const t = (i + 1) / (coils * 2);
      const y = yTop + (y0 - yTop) * t;
      const x = cx + (i % 2 === 0 ? 9 : -9);
      ctx.lineTo(x, y);
    }
    ctx.lineTo(cx, y0);
    ctx.lineWidth = 3;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = c > 0.9 ? '#ffd257' : COLORS.lane;
    ctx.shadowColor = ctx.strokeStyle;
    ctx.shadowBlur = 6 + c * 10;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // plate (the ball sits directly on this)
    ctx.beginPath();
    ctx.roundRect(501, plateY - 3, 24, 5, 2);
    ctx.fillStyle = '#2e2670';
    ctx.fill();
    ctx.strokeStyle = COLORS.lane;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.restore();
  }

  private drawBall(ctx: CanvasRenderingContext2D, v: GameView): void {
    // comet trail
    const n = v.trail.length;
    for (let i = 0; i < n; i++) {
      const t = (i + 1) / n;
      const p = v.trail[i];
      ctx.beginPath();
      ctx.globalAlpha = t * 0.22;
      ctx.fillStyle = '#7fd8ff';
      ctx.arc(p.x, p.y, 4 + t * 6, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    if (!v.ball) return;
    const { x, y } = v.ball.position;
    ctx.save();
    // glow
    ctx.beginPath();
    ctx.arc(x, y, 14, 0, Math.PI * 2);
    ctx.shadowColor = 'rgba(160,220,255,0.9)';
    ctx.shadowBlur = 16;
    ctx.fillStyle = 'rgba(140,210,255,0.35)';
    ctx.fill();
    // chrome body
    const g = ctx.createRadialGradient(x - 4, y - 5, 1, x, y, 12);
    g.addColorStop(0, '#ffffff');
    g.addColorStop(0.35, '#dfeaff');
    g.addColorStop(0.8, '#7d92c9');
    g.addColorStop(1, '#3d4a78');
    ctx.beginPath();
    ctx.arc(x, y, 11, 0, Math.PI * 2);
    ctx.shadowBlur = 8;
    ctx.fillStyle = g;
    ctx.fill();
    ctx.shadowBlur = 0;
    // sparkle that follows rotation
    const a = v.ball.angle;
    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    ctx.beginPath();
    ctx.arc(x + Math.cos(a) * 5, y + Math.sin(a) * 5, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}
