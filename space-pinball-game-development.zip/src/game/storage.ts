import { HISCORE_KEY, HISCORE_MAX } from './constants';

export interface HiScore {
  name: string;
  score: number;
  date: number;
}

/** Safely read the local top-10 table from localStorage. */
export function loadHiScores(): HiScore[] {
  try {
    const raw = localStorage.getItem(HISCORE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (e): e is HiScore =>
          typeof e === 'object' &&
          e !== null &&
          typeof (e as HiScore).name === 'string' &&
          typeof (e as HiScore).score === 'number'
      )
      .slice(0, HISCORE_MAX);
  } catch {
    return [];
  }
}

export function saveHiScores(list: HiScore[]): void {
  try {
    localStorage.setItem(HISCORE_KEY, JSON.stringify(list.slice(0, HISCORE_MAX)));
  } catch {
    /* storage unavailable — ignore */
  }
}

/** Returns the rank (0-based) the score would take, or -1 if it doesn't qualify. */
export function qualifies(score: number): boolean {
  if (score <= 0) return false;
  const list = loadHiScores();
  return list.length < HISCORE_MAX || score > list[list.length - 1].score;
}

/** Insert a score and persist. Returns the rank (0-based). */
export function insertHiScore(name: string, score: number): number {
  const list = loadHiScores();
  const entry: HiScore = { name: name.trim().slice(0, 12) || 'PLAYER', score, date: Date.now() };
  list.push(entry);
  list.sort((a, b) => b.score - a.score);
  const trimmed = list.slice(0, HISCORE_MAX);
  saveHiScores(trimmed);
  return trimmed.indexOf(entry);
}

export function bestScore(): number {
  const list = loadHiScores();
  return list.length > 0 ? list[0].score : 0;
}
