import Matter from 'matter-js';
import {
  BALL_SAVE_MS,
  BALLS_PER_GAME,
  CHARGE_TIME_MS,
  COLORS,
  COMBO_MAX,
  COMBO_WINDOW_MS,
  LAUNCH_MAX,
  LAUNCH_MIN,
  MAX_BALL_SPEED,
  PLANETS,
  SCORE,
  VIEW_W,
} from './constants';
import { Particles } from './particles';
import { Renderer } from './renderer';
import type { GameView } from './renderer';
import { SoundManager } from '../audio/sound';
import { buildTable, makeBall, SPAWN } from '../physics/table';
import type { TableParts } from '../physics/table';
import { Flipper } from '../physics/flippers';
import { ScreenManager } from '../ui/screens';
import * as store from './storage';

const { Engine, Events, Composite, Body, Vector } = Matter;

const STEP_MS = 1000 / 60;
const NEVER = -9999;

export type GameState = 'menu' | 'playing' | 'paused' | 'over';
export type BallState = 'idle' | 'ready' | 'charging' | 'live';

export class Game {
  private renderer: Renderer;
  private sound = new SoundManager();
  private particles = new Particles();
  private ui: ScreenManager;
  private engine: Matter.Engine;
  private table: TableParts;
  private flipL = new Flipper('left', 196, 856);
  private flipR = new Flipper('right', 344, 856);
  private ball: Matter.Body | null = null;

  state: GameState = 'menu';
  private ballState: BallState = 'idle';

  private score = 0;
  private combo = 0;
  private comboT = 0; // ms remaining
  private ballsLeft = BALLS_PER_GAME;

  private time = 0; // seconds, monotonic game clock
  private last = 0;
  private acc = 0;
  private raf = 0;
  private destroyed = false;

  // effects bookkeeping
  private bumperFlash: number[] = PLANETS.map(() => NEVER);
  private starFlash: number[] = [NEVER, NEVER, NEVER];
  private slingFlash: number[] = [NEVER, NEVER];
  private rampFlash = NEVER;
  private orbitFlash = NEVER;
  private drainFlash = NEVER;
  private starsLit: boolean[] = [false, false, false];
  private bumperCd: number[] = PLANETS.map(() => 0);
  private starCd: number[] = [0, 0, 0];
  private slingCd: number[] = [0, 0];
  private rampCd = 0;
  private orbitCd = 0;

  private bankResetT = 0;
  private respawnT = 0;
  private stuckT = 0;
  private launchAt = 0;

  private shakeE = 0;
  private shakeX = 0;
  private shakeY = 0;
  private trail: { x: number; y: number }[] = [];

  // input
  private leftSources = new Set<string>();
  private rightSources = new Set<string>();
  private chargeStart = 0;
  private charge = 0;
  private launchPointer: number | null = null;
  private dragStartY = 0;
  private dragPower = 0;

  constructor(container: HTMLElement) {
    const canvas = document.createElement('canvas');
    canvas.className = 'spb-canvas';
    container.appendChild(canvas);
    this.renderer = new Renderer(canvas);

    this.engine = Engine.create();
    this.engine.gravity.y = 0.75;
    this.engine.positionIterations = 8;
    this.engine.velocityIterations = 6;

    this.table = buildTable();
    Composite.add(this.engine.world, this.table.bodies);
    Composite.add(this.engine.world, [this.flipL.body, this.flipL.pin, this.flipR.body, this.flipR.pin]);

    Events.on(this.engine, 'collisionStart', (e) => this.onCollisions(e.pairs));

    this.ui = new ScreenManager(container, {
      onPlay: () => { this.sound.init(); this.sound.play('click'); this.startGame(); },
      onResume: () => { this.sound.play('click'); this.togglePause(); },
      onRestart: () => { this.sound.play('click'); this.startGame(); },
      onMenu: () => { this.sound.play('click'); this.toMenu(); },
      onPause: () => this.togglePause(),
      onMute: () => this.mute(),
      onSaveName: (name: string) => {
        const rank = store.insertHiScore(name, this.score);
        this.ui.showGameOverSaved(store.loadHiScores(), rank);
      },
    });

    this.spawnBall('idle');
    this.ui.showStart(store.loadHiScores(), store.bestScore());

    window.addEventListener('keydown', this.onKeyDown, { passive: false });
    window.addEventListener('keyup', this.onKeyUp, { passive: false });
    window.addEventListener('blur', this.onBlur);
    canvas.addEventListener('pointerdown', this.onPointerDown, { passive: false });
    canvas.addEventListener('pointermove', this.onPointerMove, { passive: false });
    canvas.addEventListener('pointerup', this.onPointerUp, { passive: false });
    canvas.addEventListener('pointercancel', this.onPointerUp, { passive: false });
    // belt & braces for older mobile browsers: block scroll/zoom gestures
    container.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
    container.addEventListener('contextmenu', (e) => e.preventDefault());
    document.addEventListener('visibilitychange', this.onVisibility);
    window.addEventListener('resize', this.onResize);

    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy(): void {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('visibilitychange', this.onVisibility);
    window.removeEventListener('resize', this.onResize);
    this.renderer.canvas.remove();
    this.ui.destroy();
    this.sound.stopMusic();
    Composite.clear(this.engine.world, false, true);
    Engine.clear(this.engine);
  }

  // ------------------------------------------------------------ lifecycle

  private startGame(): void {
    this.score = 0;
    this.combo = 0;
    this.comboT = 0;
    this.ballsLeft = BALLS_PER_GAME;
    this.starsLit = [false, false, false];
    this.particles.clear();
    this.state = 'playing';
    this.spawnBall('ready');
    this.ui.enterGame(this.ballsLeft, store.bestScore());
    this.ui.setScore(0);
    this.ui.setCombo(0);
    this.ui.toast('LAUNCH WHEN READY!');
    this.ui.setHint('HOLD SPACE — or pull down — to launch');
    this.sound.startMusic();
  }

  private toMenu(): void {
    this.state = 'menu';
    this.spawnBall('idle');
    this.ui.showStart(store.loadHiScores(), store.bestScore());
    this.sound.duckMusic(false);
  }

  private spawnBall(state: BallState): void {
    if (this.ball) Composite.remove(this.engine.world, this.ball);
    this.ball = makeBall();
    Composite.add(this.engine.world, this.ball);
    this.ballState = state;
    this.stuckT = 0;
    this.charge = 0;
    this.launchPointer = null;
    this.launchAt = 0;
  }

  private togglePause(): void {
    if (this.state === 'playing') {
      this.state = 'paused';
      if (this.ballState === 'charging') this.ballState = 'ready'; // cancel held plunger
      this.launchPointer = null;
      this.ui.showPause(true);
      this.ui.setHint(null);
      this.sound.duckMusic(true);
    } else if (this.state === 'paused') {
      this.state = 'playing';
      this.ui.showPause(false);
      this.refreshHint();
      this.sound.duckMusic(false);
      this.last = performance.now(); // avoid a giant dt burst
      this.acc = 0;
    }
  }

  private mute(): void {
    this.sound.init();
    this.ui.syncMute(this.sound.toggleMute());
  }

  private gameOver(): void {
    this.state = 'over';
    this.ballState = 'idle';
    this.ui.setHint(null);
    this.sound.play('gameover');
    this.sound.duckMusic(true);
    this.particles.burst(270, 500, '#ffd257', 40, 9, 'star');
    this.ui.showGameOver(this.score, store.loadHiScores(), store.qualifies(this.score));
  }

  // ------------------------------------------------------------- updates

  private loop = (now: number): void => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.loop);
    let dt = now - this.last;
    this.last = now;
    if (dt > 100) dt = 100; // tab-back resume safety
    this.time += dt / 1000;

    if (this.state === 'playing') {
      this.acc += dt;
      let steps = 0;
      while (this.acc >= STEP_MS && steps < 3) {
        this.fixedUpdate(STEP_MS / 1000);
        this.acc -= STEP_MS;
        steps++;
      }
      if (steps === 3) this.acc = 0;
    }

    // charge power (smooth even between physics ticks)
    if (this.ballState === 'charging') {
      const ramp = Math.min(1, (now - this.chargeStart) / CHARGE_TIME_MS);
      this.charge = Math.max(ramp, this.dragPower);
      if (this.charge >= 1) this.charge = 1;
    } else {
      this.charge = 0;
    }

    if (this.state !== 'paused') this.particles.update(Math.min(dt, 50) / 1000);

    // screen shake
    this.shakeE *= Math.exp(-dt / 130);
    this.shakeX = (Math.random() * 2 - 1) * this.shakeE;
    this.shakeY = (Math.random() * 2 - 1) * this.shakeE;

    // ball trail
    if (this.ball && (this.ballState === 'live' || this.ballState === 'charging')) {
      this.trail.push({ x: this.ball.position.x, y: this.ball.position.y });
      if (this.trail.length > 14) this.trail.shift();
    } else if (this.trail.length > 0) {
      this.trail.shift();
    }

    this.renderer.draw(this.view());
  };

  private fixedUpdate(dt: number): void {
    this.flipL.update();
    this.flipR.update();

    // keep the ball pinned on the spring while charging
    if (this.ball && this.ballState === 'charging') {
      Body.setPosition(this.ball, { x: SPAWN.x, y: SPAWN.y + this.charge * 14 });
      Body.setVelocity(this.ball, { x: 0, y: 0 });
    }

    Engine.update(this.engine, STEP_MS);

    // combo decay
    if (this.combo > 0) {
      this.comboT -= dt * 1000;
      if (this.comboT <= 0) {
        this.combo = 0;
        this.ui.setCombo(0);
      }
    }

    // star bank reset
    if (this.bankResetT > 0) {
      this.bankResetT -= dt;
      if (this.bankResetT <= 0) {
        this.starsLit = [false, false, false];
      }
    }

    // respawn next ball after a drain
    if (this.respawnT > 0) {
      this.respawnT -= dt;
      if (this.respawnT <= 0 && this.state === 'playing') {
        this.spawnBall('ready');
        this.ui.toast(`BALL ${BALLS_PER_GAME - this.ballsLeft + 1} — READY!`);
        this.refreshHint();
      }
    }

    if (this.ball) this.guardBall(dt);
  }

  private guardBall(dt: number): void {
    const b = this.ball!;
    // top speed clamp (also prevents tunneling)
    const sp = Vector.magnitude(b.velocity);
    if (sp > MAX_BALL_SPEED) {
      Body.setVelocity(b, Vector.mult(Vector.normalise(b.velocity), MAX_BALL_SPEED));
    }
    // a ball that falls back into the launch lane becomes ready again
    if (this.ballState === 'live' && b.position.x > 496 && b.position.y > 830 && sp < 3) {
      this.ballState = 'ready';
      this.refreshHint();
      this.ui.toast('RE-LAUNCH!');
      this.launchAt = 0;
    }
    // anti-stuck: nudge a sleeping ball in the open field (cradled balls
    // sitting on a flipper, y>780, are legitimate — leave them be)
    if (this.ballState === 'live' && sp < 0.3 && b.position.y < 780) {
      this.stuckT += dt;
      if (this.stuckT > 2.4) {
        Body.setVelocity(b, { x: (Math.random() - 0.5) * 4, y: -6 });
        this.stuckT = 0;
      }
    } else {
      this.stuckT = 0;
    }
    // catastrophic escape failsafe — treat as a drain
    if (b.position.y < -60 || b.position.y > 1030 || b.position.x < -60 || b.position.x > 620) {
      this.onDrain();
    }
  }

  // ------------------------------------------------------------- scoring

  private mult(): number {
    return Math.max(this.combo, 1);
  }

  private addScore(base: number, x: number, y: number, color: string): number {
    const pts = base * this.mult();
    this.score += pts;
    this.ui.setScore(this.score);
    this.particles.popup(x, y, `+${pts}`, color, pts >= 500 ? 26 : 20);
    return pts;
  }

  private bumpCombo(): void {
    this.combo = Math.min(this.combo + 1, COMBO_MAX);
    this.comboT = COMBO_WINDOW_MS;
    this.ui.setCombo(this.combo);
    if (this.combo === 3 || this.combo === 5 || this.combo === 8) {
      this.ui.toast(`COMBO ×${this.combo}!`);
    }
  }

  private refreshCombo(): void {
    if (this.combo > 0) this.comboT = COMBO_WINDOW_MS;
  }

  private shake(amount: number): void {
    this.shakeE = Math.min(16, this.shakeE + amount);
  }

  // ---------------------------------------------------------- collisions

  private onCollisions(pairs: Matter.Pair[]): void {
    if (this.state !== 'playing' || !this.ball) return;
    for (const pair of pairs) {
      const { bodyA, bodyB } = pair;
      let other: Matter.Body | null = null;
      if (bodyA.label === 'ball') other = bodyB;
      else if (bodyB.label === 'ball') other = bodyA;
      if (!other) continue;
      const label = other.label;

      if (label.startsWith('bumper:')) this.onBumper(Number(label.split(':')[1]), other);
      else if (label.startsWith('star:')) this.onStar(Number(label.split(':')[1]));
      else if (label === 'sling') this.onSling(other);
      else if (label === 'ramp') this.onRamp();
      else if (label === 'orbit') this.onOrbit();
      else if (label === 'drain') this.onDrain();
    }
  }

  private onBumper(i: number, bumper: Matter.Body): void {
    if (!this.ball || this.time - this.bumperCd[i] < 0.06) return;
    this.bumperCd[i] = this.time;
    const p = PLANETS[i];

    // pop-bumper kick: blast the ball away from the planet center
    let dir = Vector.sub(this.ball.position, bumper.position);
    if (Vector.magnitude(dir) < 0.001) dir = { x: 0, y: 1 };
    dir = Vector.normalise(dir);
    const speed = Math.max(12.5, Vector.magnitude(this.ball.velocity) * 1.05);
    Body.setVelocity(this.ball, Vector.mult(dir, speed));

    this.bumpCombo();
    this.bumperFlash[i] = this.time;
    this.addScore(SCORE.bumper, p.x, p.y - p.r - 14, p.glow);
    this.particles.burst(this.ball.position.x, this.ball.position.y, p.glow, 16, 7.5, 'line');
    this.particles.burst(p.x, p.y, '#ffffff', 5, 3, 'dot');
    this.shake(3.6);
    this.sound.play('bumper', this.combo / COMBO_MAX);
  }

  private onStar(i: number): void {
    if (!this.ball || this.time - this.starCd[i] < 0.15) return;
    this.starCd[i] = this.time;
    this.refreshCombo();
    this.starFlash[i] = this.time;
    const s = this.ball.position;
    this.addScore(SCORE.star, s.x, s.y - 18, '#ffd257');
    this.particles.burst(s.x, s.y, '#ffd257', 12, 6, 'star');
    this.sound.play('star');
    this.shake(2);

    if (!this.starsLit[i]) {
      this.starsLit[i] = true;
      if (this.starsLit.every(Boolean)) {
        this.bankResetT = 0.9;
        this.addScore(SCORE.starBankBonus, 270, 560, '#ffe98f');
        this.particles.popup(270, 520, 'STAR BONUS!', '#ffe98f', 30);
        this.particles.burst(466, 502, '#ffd257', 26, 8, 'star');
        this.sound.play('bonus');
        this.shake(4.5);
      }
    }
  }

  private onSling(sling: Matter.Body): void {
    const i = this.table.slings.findIndex((s) => s.body === sling);
    if (i < 0 || !this.ball || this.time - this.slingCd[i] < 0.12) return;
    this.slingCd[i] = this.time;
    this.refreshCombo();
    const kick = this.table.slings[i].kick;
    const cur = this.ball.velocity;
    Body.setVelocity(this.ball, {
      x: kick.x * 11 + cur.x * 0.2,
      y: kick.y * 11 + cur.y * 0.2,
    });
    this.slingFlash[i] = this.time;
    this.addScore(SCORE.sling, this.ball.position.x, this.ball.position.y - 16, '#ff8ac2');
    this.particles.burst(this.ball.position.x, this.ball.position.y, COLORS.sling, 10, 5.5, 'line');
    this.sound.play('sling');
    this.shake(2.4);
  }

  private onRamp(): void {
    if (!this.ball || this.time - this.rampCd < 1.2) return;
    this.rampCd = this.time;
    this.refreshCombo();
    this.rampFlash = this.time;
    this.addScore(SCORE.ramp, 372, 140, COLORS.ramp);
    this.particles.popup(372, 116, 'COSMIC RAMP!', COLORS.ramp, 24);
    this.particles.burst(372, 96, COLORS.ramp, 18, 6, 'star');
    this.sound.play('ramp');
    this.shake(3);
  }

  private onOrbit(): void {
    if (!this.ball || this.time - this.orbitCd < 1.5) return;
    this.orbitCd = this.time;
    this.refreshCombo();
    this.orbitFlash = this.time;
    this.addScore(SCORE.orbit, 70, 440, COLORS.orbit);
    this.particles.popup(80, 410, 'ORBIT!', COLORS.orbit, 26);
    this.particles.burst(35, 468, COLORS.orbit, 16, 7, 'star');
    this.sound.play('orbit');
    this.shake(4);
  }

  private onDrain(): void {
    if (!this.ball || this.state !== 'playing') return;
    const pos = { ...this.ball.position };

    // kid-friendly ball saver right after launch
    const sinceLaunch = performance.now() - this.launchAt;
    if (this.ballState === 'live' && this.launchAt > 0 && sinceLaunch < BALL_SAVE_MS) {
      this.drainFlash = this.time;
      this.sound.play('save');
      this.ui.toast('BALL SAVED!');
      this.particles.popup(270, 640, 'BALL SAVED!', COLORS.flipper, 30);
      this.particles.burst(pos.x, Math.min(pos.y, 900), COLORS.flipper, 18, 7, 'star');
      this.shake(3);
      Body.setPosition(this.ball, { x: SPAWN.x, y: SPAWN.y });
      Body.setVelocity(this.ball, { x: 0, y: 0 });
      this.ballState = 'ready';
      this.launchAt = 0; // one rescue per launch
      this.refreshHint();
      return;
    }

    this.drainFlash = this.time;
    this.sound.play('drain');
    this.particles.burst(pos.x, Math.min(pos.y, 900), '#ff5a7a', 22, 8, 'line');
    this.shake(7);
    this.combo = 0;
    this.ui.setCombo(0);
    this.starsLit = [false, false, false];

    Composite.remove(this.engine.world, this.ball);
    this.ball = null;
    this.ballState = 'idle';
    this.ballsLeft--;
    this.ui.setBalls(this.ballsLeft);

    if (this.ballsLeft <= 0) {
      this.ui.toast('GAME OVER');
      this.gameOver();
    } else {
      this.ui.toast('BALL LOST');
      this.respawnT = 1.0;
    }
  }

  // -------------------------------------------------------------- launch

  private startCharge(): void {
    if (this.state !== 'playing' || this.ballState !== 'ready') return;
    this.ballState = 'charging';
    this.chargeStart = performance.now();
    this.dragPower = 0;
    this.ui.setHint('Release to BLAST OFF!');
  }

  private releaseCharge(): void {
    if (this.state !== 'playing') return; // ignore releases on pause/menu screens
    if (this.ballState !== 'charging' || !this.ball) return;
    const power = Math.max(0.12, this.charge);
    Body.setPosition(this.ball, { x: SPAWN.x, y: SPAWN.y });
    Body.setVelocity(this.ball, { x: 0, y: -(LAUNCH_MIN + power * (LAUNCH_MAX - LAUNCH_MIN)) });
    this.ballState = 'live';
    this.launchAt = performance.now();
    this.charge = 0;
    this.dragPower = 0;
    this.ui.setHint(null);
    this.sound.play('launch', power);
    this.particles.burst(SPAWN.x, 930, '#ffd257', 10 + Math.round(power * 12), 5 + power * 5, 'line');
    this.shake(1.5 + power * 2.5);
  }

  private refreshHint(): void {
    if (this.state !== 'playing') {
      this.ui.setHint(null);
    } else if (this.ballState === 'ready') {
      this.ui.setHint('HOLD SPACE — or pull down — to launch');
    } else {
      this.ui.setHint(null);
    }
  }

  // ---------------------------------------------------------------- input

  private press(set: Set<string>, src: string, flipper: Flipper): void {
    set.add(src);
    flipper.setPressed(true);
    if (this.state !== 'playing') return;
    this.sound.play('flipper');
    this.flipperAssist(flipper);
  }

  /** Guaranteed juicy punt when the ball is anywhere over the blade. */
  private flipperAssist(f: Flipper): void {
    if (!this.ball || this.ballState !== 'live') return;
    const b = this.ball;
    const dx = b.position.x - f.pivot.x;
    const dy = b.position.y - f.pivot.y;
    if (Math.abs(dx) > 108 || dy < -75 || dy > 28) return;
    const dir = f.side === 'left' ? 1 : -1;
    Body.setVelocity(b, {
      x: b.velocity.x * 0.55 + dir * 3.2,
      y: Math.min(b.velocity.y * 0.4, -13.5),
    });
    this.particles.burst(f.pivot.x + dir * 36, f.pivot.y - 16, COLORS.flipper, 6, 4, 'dot');
  }

  private release(set: Set<string>, src: string, flipper: Flipper): void {
    set.delete(src);
    if (set.size === 0) flipper.setPressed(false);
  }

  private onKeyDown = (e: KeyboardEvent): void => {
    if (e.code === 'ArrowLeft' || e.code === 'ArrowRight' || e.code === 'Space') e.preventDefault();
    this.sound.init();

    switch (e.code) {
      case 'ArrowLeft':
        if (!e.repeat && this.state === 'playing') this.press(this.leftSources, 'kbd', this.flipL);
        break;
      case 'ArrowRight':
        if (!e.repeat && this.state === 'playing') this.press(this.rightSources, 'kbd', this.flipR);
        break;
      case 'Space':
        if (e.repeat) break;
        if (this.state === 'menu') {
          this.sound.play('click');
          this.startGame();
        } else if (this.state === 'playing') {
          this.startCharge();
        }
        break;
      case 'Enter':
        if (this.state === 'menu' || this.state === 'over') {
          this.sound.play('click');
          this.startGame();
        } else if (this.state === 'paused') {
          this.togglePause();
        }
        break;
      case 'KeyP':
      case 'Escape':
        this.togglePause();
        break;
      case 'KeyM':
        this.mute();
        break;
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    switch (e.code) {
      case 'ArrowLeft':
        this.release(this.leftSources, 'kbd', this.flipL);
        break;
      case 'ArrowRight':
        this.release(this.rightSources, 'kbd', this.flipR);
        break;
      case 'Space':
        this.releaseCharge();
        break;
    }
  };

  private onBlur = (): void => {
    this.leftSources.clear();
    this.rightSources.clear();
    this.flipL.setPressed(false);
    this.flipR.setPressed(false);
    if (this.state === 'playing' && this.ballState === 'charging') {
      this.ballState = 'ready'; // cancel a charge interrupted by alt-tab
    }
  };

  private onVisibility = (): void => {
    if (document.hidden) {
      if (this.state === 'playing') this.togglePause();
      this.sound.suspend();
    } else {
      this.sound.resume();
    }
  };

  private onResize = (): void => {
    this.renderer.resize();
  };

  private onPointerDown = (e: PointerEvent): void => {
    e.preventDefault();
    this.sound.init();
    if (this.state !== 'playing') return;
    const p = this.renderer.toVirtual(e.clientX, e.clientY);

    // launch zone: right side of the table while the ball sits on the plunger
    if (this.ballState === 'ready' && p.x > VIEW_W * 0.6 && p.y > 300) {
      this.launchPointer = e.pointerId;
      this.dragStartY = p.y;
      this.startCharge();
      return;
    }
    if (p.x < VIEW_W / 2) this.press(this.leftSources, `ptr${e.pointerId}`, this.flipL);
    else this.press(this.rightSources, `ptr${e.pointerId}`, this.flipR);
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (this.launchPointer !== e.pointerId || this.ballState !== 'charging') return;
    const p = this.renderer.toVirtual(e.clientX, e.clientY);
    const pull = (p.y - this.dragStartY) / 200;
    this.dragPower = Math.max(0, Math.min(1, pull));
  };

  private onPointerUp = (e: PointerEvent): void => {
    if (this.launchPointer === e.pointerId) {
      this.launchPointer = null;
      this.releaseCharge();
      return;
    }
    this.release(this.leftSources, `ptr${e.pointerId}`, this.flipL);
    this.release(this.rightSources, `ptr${e.pointerId}`, this.flipR);
  };

  // ---------------------------------------------------------------- view

  private view(): GameView {
    return {
      time: this.time,
      ball: this.ball,
      trail: this.trail,
      alive: this.ball !== null,
      flipL: this.flipL,
      flipR: this.flipR,
      wallSegs: this.table.wallSegs,
      slingSegs: this.table.slingSegs,
      ballState: this.ballState,
      charge: this.charge,
      bumperFlash: this.bumperFlash,
      starFlash: this.starFlash,
      starsLit: this.starsLit,
      slingFlash: this.slingFlash,
      rampFlash: this.rampFlash,
      orbitFlash: this.orbitFlash,
      drainFlash: this.drainFlash,
      shakeX: this.shakeX,
      shakeY: this.shakeY,
      particles: this.particles,
    };
  }
}
