Space Pinball Blast — audio drop-in folder
==========================================

Drop your royalty-free audio files here using EXACTLY these filenames.
The game loads them automatically. Every file is optional: if a file is
missing, the game falls back to a built-in synthesized sound, so it is
fully playable with zero audio files present.

Music (loops during gameplay)
  music.mp3        — background music loop

Sound effects
  flipper.wav      — flipper snap
  bumper.wav       — planet bumper hit
  star.wav         — star target hit
  sling.wav        — slingshot kick
  launch.wav       — plunger launch
  drain.wav        — ball lost
  orbit.wav        — orbit lane completed
  ramp.wav         — cosmic ramp scored
  bonus.wav        — star bank bonus / fanfare
  save.wav         — ball saver chime
  gameover.wav     — game over jingle
  click.wav        — UI button click

Tips: keep SFX short (< 1s), normalized WAV or MP3 both work.
Music should be a seamless loop, ~30–90 seconds, MP3 or OGG.
