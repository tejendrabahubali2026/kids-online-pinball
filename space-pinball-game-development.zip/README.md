# 🪐 Space Pinball Blast

A kid-friendly, neon space-themed 2D pinball game for the browser.
Real physics powered by **Matter.js**, rendered on an HTML5 Canvas,
with a pulsing synth soundtrack and Web Audio sound effects (drop in
your own audio files — see `public/sounds/README.txt`).

Built with **Vite + TypeScript**.

## Features

- 🪐 **Planet bumpers**, ⭐ star target bank, pink **slingshots**, an
  **orbit lane**, a **cosmic ramp**, and a one-way **launch-lane gate**
- 🕹️ Tight controls — `←` / `→` flippers, hold `SPACE` to charge the
  plunger; on touch devices tap the left/right half to flip and
  **press & pull down on the right side** to launch
- 🏆 3 balls per game, live score, combo multiplier (chain bumper hits!),
  ball-saver for the first seconds after launch
- ⏸️ Pause (`P` / `ESC` or the on-screen button), mute (`M`)
- 💾 Local top-10 high-score table with name entry (localStorage)
- ✨ Juice everywhere: screen shake, spark particles, floating score
  popups, squash-and-stretch planets, flipper streaks
- 📱 Responsive letterboxed canvas, 60 fps on desktop and mobile

## Run locally

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
```

The production bundle is written to **`/dist`** — deploy that folder to
**Cloudflare Pages** (or any static host).

Preview the production build locally with:

```bash
npm run preview
```

## Project structure

```
index.html              # page shell (loads /src/main.ts)
public/sounds/          # drop optional music.mp3 / sfx .wav files here
src/
  main.ts               # entry — boots the game
  game/
    constants.ts        # layout, palette, scoring constants
    game.ts             # game state machine, scoring, input, main loop
    renderer.ts         # canvas rendering (table, planets, particles…)
    particles.ts        # spark particles + floating score popups
    storage.ts          # localStorage high-score table
    styles.css          # neon UI theme
  physics/
    table.ts            # Matter.js playfield (walls, arc, lane, sensors)
    flippers.ts         # constraint-driven flipper controller
  audio/
    sound.ts            # Web Audio manager (file → synth fallback, music)
  ui/
    screens.ts          # start / pause / game-over screens + HUD
```

## Physics smoke tests (optional)

A headless Matter.js simulation that validates the launch arc, orbit lane,
slingshots, star targets, drains and flipper punts lives in `tools/sim.ts`:

```bash
npx esbuild tools/sim.ts --bundle --platform=node --format=esm --outfile=/tmp/sim.mjs
node /tmp/sim.mjs
```

## Custom audio

All audio paths are placeholders — the game synthesizes fallback sounds
when files are absent. To use your own royalty-free tracks, drop them
into `public/sounds/` using the filenames listed in
`public/sounds/README.txt`.
