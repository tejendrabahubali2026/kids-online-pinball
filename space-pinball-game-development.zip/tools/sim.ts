/* Headless physics smoke test — not shipped. Run via esbuild bundle. */
import Matter from 'matter-js';
import { buildTable, makeBall } from '../src/physics/table';
import { SPAWN } from '../src/physics/table';
import { LAUNCH_MAX, LAUNCH_MIN, MAX_BALL_SPEED } from '../src/game/constants';
import { Flipper } from '../src/physics/flippers';

const { Engine, Composite, Body, Events, Vector } = Matter;

function newWorld(): { engine: Matter.Engine; ball: Matter.Body; events: string[] } {
  const engine = Engine.create();
  engine.gravity.y = 0.75;
  engine.positionIterations = 8;
  engine.velocityIterations = 6;
  const table = buildTable();
  Composite.add(engine.world, table.bodies);
  const ball = makeBall();
  Composite.add(engine.world, ball);
  const events: string[] = [];
  Events.on(engine, 'collisionStart', (e) => {
    for (const p of e.pairs) {
      const a = p.bodyA.label;
      const b = p.bodyB.label;
      const other = a === 'ball' ? b : b === 'ball' ? a : null;
      if (other) events.push(other);
    }
  });
  return { engine, ball, events };
}

function step(engine: Matter.Engine, ball: Matter.Body, n: number, track?: { minY: number; minX: number; maxX: number }): void {
  for (let i = 0; i < n; i++) {
    Engine.update(engine, 1000 / 60);
    const sp = Vector.magnitude(ball.velocity);
    if (sp > MAX_BALL_SPEED) Body.setVelocity(ball, Vector.mult(Vector.normalise(ball.velocity), MAX_BALL_SPEED));
    if (track) {
      track.minY = Math.min(track.minY, ball.position.y);
      track.minX = Math.min(track.minX, ball.position.x);
      track.maxX = Math.max(track.maxX, ball.position.x);
    }
  }
}

// ---- TEST 1: full-power launch orbits to the left side ----
{
  const { engine, ball, events } = newWorld();
  Body.setVelocity(ball, { x: 0, y: -LAUNCH_MAX });
  const track = { minY: 999, minX: 999, maxX: 0 };
  step(engine, ball, 300, track);
  console.log('T1 full launch  → minY=%s  xRange=[%s, %s]  end=(%s, %s)',
    track.minY.toFixed(0), track.minX.toFixed(0), track.maxX.toFixed(0),
    ball.position.x.toFixed(0), ball.position.y.toFixed(0));
  console.log('   sensors hit:', events.filter((e) => e === 'ramp' || e === 'orbit' || e === 'drain' || e.startsWith('bumper')).join(', ') || '(none)');
  console.log('   PASS orbit-left?', track.minX < 90 ? 'YES' : 'no', '| ball in bounds?', isFinite(ball.position.x) && ball.position.y < 1000 ? 'YES' : 'NO');
}

// ---- TEST 2: weakest launch still leaves the lane ----
{
  const { engine, ball, events } = newWorld();
  Body.setVelocity(ball, { x: 0, y: -LAUNCH_MIN });
  const track = { minY: 999, minX: 999, maxX: 0 };
  step(engine, ball, 300, track);
  const leftLane = track.minX < 490;
  console.log('T2 weak launch  → minY=%s  leftLane=%s  end=(%s, %s)  events=%s',
    track.minY.toFixed(0), leftLane, ball.position.x.toFixed(0), ball.position.y.toFixed(0),
    events.slice(0, 6).join(','));
}

// ---- TEST 3: a ball dropped above the flippers eventually drains ----
{
  const { engine, ball, events } = newWorld();
  Body.setPosition(ball, { x: 270, y: 700 });
  Body.setVelocity(ball, { x: 0, y: 0 });
  step(engine, ball, 240);
  console.log('T3 dropped ball → drained?', events.includes('drain') ? 'YES' : 'no', ' end=(%s, %s)', ball.position.x.toFixed(0), ball.position.y.toFixed(0));
}

// ---- TEST 4: ball resting on the plunger stays put ----
{
  const { engine, ball } = newWorld();
  step(engine, ball, 120);
  const dx = Math.abs(ball.position.x - SPAWN.x);
  const dy = Math.abs(ball.position.y - SPAWN.y);
  console.log('T4 rest on plunger → drift=(%s px, %s px)', dx.toFixed(1), dy.toFixed(1));
}

// ---- TEST 5: flipper punt — ball parked on left flipper gets lifted ----
{
  const engine = Engine.create();
  engine.gravity.y = 0.75;
  const table = buildTable();
  const fl = new Flipper('left', 196, 856);
  const fr = new Flipper('right', 344, 856);
  Composite.add(engine.world, [...table.bodies, fl.body, fl.pin, fr.body, fr.pin]);
  const ball = makeBall();
  Composite.add(engine.world, ball);
  Body.setPosition(ball, { x: 237, y: 850 });
  Body.setVelocity(ball, { x: 0, y: 0 });
  for (let i = 0; i < 40; i++) { fl.update(); fr.update(); Engine.update(engine, 1000 / 60); }
  console.log('   rest: ball=(%s, %s) flipperAngle=%s (rest 0.56)',
    ball.position.x.toFixed(0), ball.position.y.toFixed(0), fl.body.angle.toFixed(2));
  fl.setPressed(true);
  let minY = 999;
  let minX = 999;
  for (let i = 0; i < 120; i++) {
    fl.update(); fr.update();
    Engine.update(engine, 1000 / 60);
    minY = Math.min(minY, ball.position.y);
    minX = Math.min(minX, ball.position.x);
    if (i === 5) console.log('   after 5 ticks pressed: angle=%s (target %s)', fl.body.angle.toFixed(2), (Math.PI - 0.56).toFixed(2));
  }
  console.log('T5 flipper punt → minY=%s minX=%s (start 237,850) | lifted?', minY.toFixed(0), minX.toFixed(0), minY < 780 ? 'YES' : 'no');
}

// ---- TEST 6: ball dropped into the left orbit lane triggers ORBIT + reaches flippers ----
{
  const { engine, ball, events } = newWorld();
  Body.setPosition(ball, { x: 36, y: 320 });
  Body.setVelocity(ball, { x: 0, y: 4 });
  step(engine, ball, 300);
  console.log('T6 orbit lane → orbit?', events.includes('orbit') ? 'YES' : 'no',
    ' sling?', events.includes('sling') ? 'YES' : 'no',
    ' drained?', events.includes('drain') ? 'YES' : 'no',
    ' end=(%s, %s)', ball.position.x.toFixed(0), ball.position.y.toFixed(0));
}

// ---- TEST 7: ball rolling down the left funnel hits the slingshot and is kicked into the field ----
{
  const { engine, ball, events } = newWorld();
  Body.setPosition(ball, { x: 30, y: 520 });
  Body.setVelocity(ball, { x: 2, y: 2 });
  step(engine, ball, 120);
  const slingIdx = events.indexOf('sling');
  console.log('T7 sling kick → sling?', slingIdx >= 0 ? 'YES' : 'no',
    ' end=(%s, %s)', ball.position.x.toFixed(0), ball.position.y.toFixed(0));
}

// ---- TEST 8: star target bank registers hits ----
{
  const { engine, ball, events } = newWorld();
  Body.setPosition(ball, { x: 430, y: 500 });
  Body.setVelocity(ball, { x: 12, y: -2 });
  step(engine, ball, 100);
  console.log('T8 star bank → star hit?', events.some((e) => e.startsWith('star')) ? 'YES' : 'no',
    ' events=', events.slice(0, 8).join(','));
}

console.log('sim done');
